<!DOCTYPE html>
<html>
<head>
    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.js"></script>
    <style>
        #calendar {
            height: 800px;
            max-width: 100%;
            margin: 20px auto;
            background: #fff;
        }
    </style>
</head>
<body>

<div id="calendar"></div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var calendarEl = document.getElementById('calendar');

    var calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        events: [
            { title: 'Test Event', start: '2025-11-15' }
        ]
    });

    calendar.render();
});
</script>

</body>
</html>
<?php /**PATH D:\Laravel Projects\MainLab\resources\views/calendar2.blade.php ENDPATH**/ ?>