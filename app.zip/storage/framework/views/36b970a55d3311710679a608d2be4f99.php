<?php $__env->startSection('title', 'Computers'); ?>
<?php $__env->startSection('nav', 'computers'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <h1>Computers</h1>
                
                <div class="separator mb-5"></div>

                <div class="row mb-4">
                    
                    <div class="col-lg-12 col-md-12 mb-4">
                        <div class="card">
                            <div class="card-body">
                                <!-- <h5 class="card-title">Light Heading</h5> -->

                                <table class="table">
                                    <thead class="thead-light">
                                        <tr>
                                            <th scope="col">Label</th>
                                            <th scope="col">LAB</th>
                                            <th scope="col">Software</th>
                                            <th scope="col">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $computers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($pc->computer_label); ?></td>
                                                
                                                <td><?php echo e($pc->lab->lab_name ?? 'N/A'); ?></td>

                                                <!-- SOFTWARE COLUMN -->
                                                <td>
                                                    <?php $__currentLoopData = $pc->software; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($sw->pivot->availability === 'Available'): ?>
                                                            <span class="badge badge-success">
                                                                ✔ <?php echo e($sw->name); ?>

                                                            </span>
                                                        <?php else: ?>
                                                            <span class="badge badge-danger">
                                                                ✘ <?php echo e($sw->name); ?>

                                                            </span>
                                                        <?php endif; ?>
                                                        <br>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </td>

                                                <!-- STATUS COLUMN -->
                                                <td>
                                                    <?php if($pc->status === 'active'): ?>
                                                        <span class="badge badge-success">Active</span>
                                                    <?php elseif($pc->status === 'slow'): ?>
                                                        <span class="badge badge-warning">Slow</span>
                                                    <?php elseif($pc->status === 'too_slow'): ?>
                                                        <span class="badge badge-danger">Too Slow</span>
                                                    <?php else: ?>
                                                        <span class="badge badge-secondary"><?php echo e($pc->status); ?></span>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Laravel Projects\MainLab\resources\views/computers.blade.php ENDPATH**/ ?>