<?php $__env->startSection('title', 'Students'); ?>
<?php $__env->startSection('nav', 'students'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <h1>Students</h1>
                
                <div class="separator mb-5"></div>

                <div class="row mb-4">
                    
                    <div class="col-lg-12 col-md-12 mb-4">
                        <div class="card">
                            <div class="card-body">
                                <!-- <h5 class="card-title">Light Heading</h5> -->

                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col">Student ID</th>
                                            <th scope="col">Start</th>
                                            <th scope="col">End</th>
                                            <th scope="col">Type</th>
                                            <th scope="col">Module</th>
                                            <th scope="col">Batch</th>
                                            <th scope="col">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e(explode(' ', $student->title)[0]); ?></td>
                                                <td><?php echo e($student->start); ?></td>
                                                <td><?php echo e($student->end); ?></td>
                                                <td><?php echo e($student->description); ?></td>
                                                <td><?php echo e($student->module); ?></td>
                                                <td><?php echo e($student->batch); ?></td>
                                                <td>
                                                    <?php if($student->status === 'Scheduled'): ?>
                                                        <span class="badge badge-success"><?php echo e($student->status); ?></span>
                                                    <?php elseif($student->status === 'Cancelled'): ?>
                                                        <span class="badge badge-warning"><?php echo e($student->status); ?></span>
                                                    <?php elseif($student->status === 'Deleted'): ?>
                                                        <span class="badge badge-danger"><?php echo e($student->status); ?></span>
                                                    <?php else: ?>
                                                        <span class="badge badge-secondary"><?php echo e($student->status); ?></span>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Laravel Projects\MainLab\resources\views/students.blade.php ENDPATH**/ ?>