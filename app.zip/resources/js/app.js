import './bootstrap';

import Calendar from '@toast-ui/calendar';

const calendar = new Calendar('#calendar', {
    defaultView: 'month'
});